"""
=========================================
VORTEX - MAIN APP WINDOW
=========================================
Matches reference: top bar with model selector
+ theme toggle, sidebar, main content area.
"""

import customtkinter as ctk
import core.config as cfg
from core.chat_manager import ChatManager
from core.ai import initialise_engine, clear_ai_history
from ui.sidebar import Sidebar
from ui.chat_area import ChatArea
from ui.welcome import WelcomeScreen


# ── Model selector options ────────────────────────────────────────────────────
MODELS = [
    "Vortex AI",
    "GPT-4o",
    "GPT-4o Mini",
    "Gemini 1.5 Flash",
    "Claude 3 Haiku",
    "Ollama (local)",
]


class VortexApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        initialise_engine()
        self.manager = ChatManager()
        self._dark = True   # always start in dark mode

        self.title(cfg.APP_NAME)
        self.geometry(f"{cfg.WINDOW_WIDTH}x{cfg.WINDOW_HEIGHT}")
        self.minsize(cfg.MIN_WIDTH, cfg.MIN_HEIGHT)
        self.configure(fg_color=cfg.BACKGROUND)
        ctk.set_appearance_mode("dark")

        self._build()
        self._refresh_sidebar()
        self._show_welcome()

    # ============================
    # LAYOUT
    # ============================

    def _build(self):

        # Root: sidebar | right_col
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # ── Sidebar ───────────────────────────────────
        self.sidebar = Sidebar(
            self,
            on_new_chat=self._new_chat,
            on_open_chat=self._open_chat,
            on_delete_chat=self._delete_chat,
            on_settings=self._open_settings,
        )
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.sidebar.bind("<<SidebarSearch>>", self._on_search)

        # ── Right column: top bar + content ───────────
        right = ctk.CTkFrame(self, fg_color=cfg.BACKGROUND, corner_radius=0)
        right.grid(row=0, column=1, sticky="nsew")
        right.grid_rowconfigure(1, weight=1)
        right.grid_columnconfigure(0, weight=1)

        # Top bar
        self._build_topbar(right)

        # Content area
        self.content = ctk.CTkFrame(right, fg_color=cfg.BACKGROUND, corner_radius=0)
        self.content.grid(row=1, column=0, sticky="nsew")
        self.content.grid_rowconfigure(0, weight=1)
        self.content.grid_columnconfigure(0, weight=1)

        self.welcome = WelcomeScreen(
            self.content,
            on_suggestion=self._send_from_suggestion,
        )
        self.chat_area = ChatArea(
            self.content,
            on_send_callback=self._handle_send,
        )

    def _build_topbar(self, parent):
        """Top bar: model dropdown (left) + theme toggle (right)."""

        bar = ctk.CTkFrame(
            parent,
            fg_color=cfg.SIDEBAR,
            corner_radius=0,
            height=58,
        )
        bar.grid(row=0, column=0, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(1, weight=1)

        # Model selector pill
        model_pill = ctk.CTkFrame(
            bar,
            fg_color=cfg.CARD,
            corner_radius=20,
        )
        model_pill.grid(row=0, column=0, padx=18, pady=10, sticky="w")
        model_pill.grid_columnconfigure(1, weight=1)

        # Small vortex icon in pill
        ctk.CTkLabel(
            model_pill,
            text="🌀",
            font=(cfg.FONT, 14),
        ).grid(row=0, column=0, padx=(10, 4), pady=6)

        self._model_var = ctk.StringVar(value="Vortex AI")
        model_menu = ctk.CTkOptionMenu(
            model_pill,
            values=MODELS,
            variable=self._model_var,
            fg_color=cfg.CARD,
            button_color=cfg.CARD,
            button_hover_color=cfg.SURFACE,
            text_color=cfg.TEXT,
            dropdown_fg_color=cfg.CARD,
            dropdown_text_color=cfg.TEXT,
            dropdown_hover_color=cfg.SURFACE,
            font=(cfg.FONT, 13, "bold"),
            width=140,
            height=32,
        )
        model_menu.grid(row=0, column=1, padx=(0, 4))

        # Theme toggle (right side)
        self._theme_btn = ctk.CTkButton(
            bar,
            text="☀",
            width=36,
            height=36,
            fg_color="transparent",
            hover_color=cfg.SURFACE,
            text_color=cfg.TEXT_SECONDARY,
            corner_radius=18,
            font=(cfg.FONT, 18),
            command=self._toggle_theme,
        )
        self._theme_btn.grid(row=0, column=2, padx=16, pady=10, sticky="e")

    # ============================
    # WELCOME / CHAT
    # ============================

    def _show_welcome(self):
        self.chat_area.grid_forget()
        self.welcome.grid(row=0, column=0, sticky="nsew")

    def _show_chat(self):
        self.welcome.grid_forget()
        self.chat_area.grid(row=0, column=0, sticky="nsew")
        self.chat_area.focus_input()

    # ============================
    # SIDEBAR ACTIONS
    # ============================

    def _refresh_sidebar(self, query=""):
        chats = self.manager.search(query) if query else self.manager.get_chats()
        self.sidebar.populate(chats)
        if self.manager.current_chat_id:
            self.sidebar.highlight(self.manager.current_chat_id)

    def _new_chat(self):
        self.manager.new_chat()
        clear_ai_history()
        self.chat_area.clear_messages()
        self._show_welcome()
        self._refresh_sidebar()

    def _open_chat(self, chat_id):
        clear_ai_history()
        messages = self.manager.open_chat(chat_id)
        self.chat_area.load_history(messages)
        self._show_chat()
        self.sidebar.highlight(chat_id)

    def _delete_chat(self, chat_id):
        self.manager.delete(chat_id)
        if self.manager.current_chat_id == chat_id:
            self.manager.new_chat()
            clear_ai_history()
            self.chat_area.clear_messages()
            self._show_welcome()
        self._refresh_sidebar()

    def _on_search(self, event):
        self._refresh_sidebar(self.sidebar.get_search_query())

    def _open_settings(self):
        from ui.settings_window import SettingsWindow
        SettingsWindow(self)

    # ============================
    # MESSAGING
    # ============================

    def _send_from_suggestion(self, text):
        self._show_chat()
        self._handle_send(text)

    def _handle_send(self, question):
        self.chat_area.add_message("user", question)
        self.chat_area.show_typing()
        self.update_idletasks()

        import threading
        def _run():
            answer = self.manager.send_message(question)
            self.after(0, lambda: self._on_reply(answer))
        threading.Thread(target=_run, daemon=True).start()

    def _on_reply(self, answer):
        self.chat_area.hide_typing()
        if answer:
            self.chat_area.add_message("assistant", answer)
        self._refresh_sidebar()
        self.sidebar.highlight(self.manager.current_chat_id)

    # ============================
    # THEME TOGGLE
    # ============================

    def _toggle_theme(self):
        self._dark = not self._dark
        mode = "dark" if self._dark else "light"
        ctk.set_appearance_mode(mode)
        self._theme_btn.configure(text="☀" if self._dark else "🌙")
