"""
=========================================
VORTEX - MESSAGE BUBBLE
=========================================
"""

import customtkinter as ctk
import core.config as cfg


class MessageBubble(ctk.CTkFrame):

    def __init__(self, parent, role, content, timestamp="", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.role    = role
        self.is_user = role == "user"
        self.grid_columnconfigure(0, weight=1)
        self._build(content, timestamp)

    def _build(self, content, timestamp):

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.grid(row=0, column=0, sticky="ew", padx=20, pady=2)
        row.grid_columnconfigure(0, weight=1)

        if self.is_user:
            bg         = cfg.USER_BUBBLE
            text_color = cfg.USER_TEXT
            anchor     = "e"
            label_color = cfg.TIFFANY_LITE if hasattr(cfg, "TIFFANY_LITE") else cfg.PRIMARY
            label      = "You"
        else:
            bg         = cfg.AI_BUBBLE
            text_color = cfg.AI_TEXT
            anchor     = "w"
            label_color = cfg.PRIMARY
            label      = "Vortex"

        # Role label
        ctk.CTkLabel(
            row,
            text=label,
            font=(cfg.FONT, 11, "bold"),
            text_color=label_color,
        ).grid(row=0, column=0, sticky=anchor, padx=4, pady=(0, 2))

        # Bubble
        bubble = ctk.CTkFrame(
            row,
            fg_color=bg,
            corner_radius=16,
        )
        bubble.grid(row=1, column=0, sticky=anchor)

        ctk.CTkLabel(
            bubble,
            text=content,
            wraplength=cfg.WRAP_LENGTH,
            justify="left",
            font=cfg.BODY_FONT,
            text_color=text_color,
        ).pack(padx=16, pady=10)

        # Timestamp
        if timestamp:
            ctk.CTkLabel(
                row,
                text=str(timestamp)[:16],
                font=cfg.SMALL_FONT,
                text_color=cfg.TEXT_SECONDARY,
            ).grid(row=2, column=0, sticky=anchor, padx=4, pady=(1, 0))
