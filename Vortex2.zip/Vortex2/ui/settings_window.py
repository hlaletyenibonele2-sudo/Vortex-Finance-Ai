"""
=========================================
VORTEX - SETTINGS WINDOW
=========================================
"""

import customtkinter as ctk
import core.config as cfg
from core.settings import (
    get_api_key, save_api_key,
    get_active_provider, save_active_provider,
    get_model, save_model,
)
from core.ai import reload_provider


class SettingsWindow(ctk.CTkToplevel):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.title("Vortex — Settings")
        self.geometry("600x540")
        self.resizable(False, False)
        self.configure(fg_color=cfg.BACKGROUND)
        self.grab_set()
        self._build()

    def _build(self):
        # Header
        hdr = ctk.CTkFrame(self, fg_color=cfg.SIDEBAR, corner_radius=0)
        hdr.pack(fill="x")

        ctk.CTkLabel(
            hdr, text="⚙  Settings",
            font=cfg.HEADING_FONT, text_color=cfg.TEXT,
        ).pack(side="left", padx=24, pady=16)

        ctk.CTkButton(
            hdr, text="✕", width=34, height=34,
            fg_color="transparent", hover_color=cfg.ERROR,
            text_color=cfg.TEXT_SECONDARY, corner_radius=8,
            command=self.destroy,
        ).pack(side="right", padx=12, pady=12)

        # Tabs
        self.tabs = ctk.CTkTabview(
            self, fg_color=cfg.BACKGROUND,
            segmented_button_fg_color=cfg.SURFACE,
            segmented_button_selected_color=cfg.PRIMARY,
            segmented_button_selected_hover_color=cfg.ACCENT,
            text_color=cfg.TEXT,
        )
        self.tabs.pack(fill="both", expand=True, padx=20, pady=16)
        for t in ("API Keys", "Provider", "About"):
            self.tabs.add(t)

        self._build_keys()
        self._build_provider()
        self._build_about()

    def _build_keys(self):
        tab = self.tabs.tab("API Keys")
        providers = [
            ("openai",    "🤖  OpenAI",        "sk-..."),
            ("gemini",    "✨  Google Gemini",  "AIza..."),
            ("anthropic", "🔷  Anthropic",      "sk-ant-..."),
        ]
        self._key_entries = {}
        for pid, label, ph in providers:
            ctk.CTkLabel(
                tab, text=label,
                font=(cfg.FONT, 13, "bold"),
                text_color=cfg.TEXT, anchor="w",
            ).pack(fill="x", padx=8, pady=(14, 3))

            row = ctk.CTkFrame(tab, fg_color="transparent")
            row.pack(fill="x", padx=8)
            row.grid_columnconfigure(0, weight=1)

            e = ctk.CTkEntry(
                row, placeholder_text=ph, height=42,
                fg_color=cfg.SURFACE, border_color=cfg.BORDER, border_width=1,
                text_color=cfg.TEXT, corner_radius=10, font=cfg.BODY_FONT, show="•",
            )
            e.grid(row=0, column=0, sticky="ew")
            e.insert(0, get_api_key(pid))

            def _tog(entry=e):
                entry.configure(show="" if entry.cget("show") == "•" else "•")

            ctk.CTkButton(
                row, text="👁", width=42, height=42,
                fg_color=cfg.SURFACE, hover_color=cfg.BORDER,
                text_color=cfg.TEXT_SECONDARY, corner_radius=10,
                command=_tog,
            ).grid(row=0, column=1, padx=(6, 0))

            self._key_entries[pid] = e

        ctk.CTkButton(
            tab, text="Save API Keys", height=42,
            fg_color=cfg.PRIMARY, hover_color=cfg.ACCENT,
            text_color="#000000", corner_radius=10,
            font=(cfg.FONT, 13, "bold"),
            command=self._save_keys,
        ).pack(fill="x", padx=8, pady=20)

    def _save_keys(self):
        for pid, e in self._key_entries.items():
            save_api_key(pid, e.get().strip())
        reload_provider()
        self._toast("API keys saved ✓")

    def _build_provider(self):
        tab = self.tabs.tab("Provider")
        ctk.CTkLabel(
            tab, text="Active Provider",
            font=(cfg.FONT, 13, "bold"),
            text_color=cfg.TEXT, anchor="w",
        ).pack(fill="x", padx=8, pady=(14, 4))

        self._pvar = ctk.StringVar(value=get_active_provider())
        ctk.CTkOptionMenu(
            tab, values=["openai", "gemini", "anthropic", "ollama"],
            variable=self._pvar,
            fg_color=cfg.SURFACE, button_color=cfg.PRIMARY,
            button_hover_color=cfg.ACCENT, text_color=cfg.TEXT,
            height=42, corner_radius=10, font=cfg.BODY_FONT,
            command=self._on_p_change,
        ).pack(fill="x", padx=8)

        ctk.CTkLabel(
            tab, text="Model",
            font=(cfg.FONT, 13, "bold"),
            text_color=cfg.TEXT, anchor="w",
        ).pack(fill="x", padx=8, pady=(16, 4))

        self._model_entry = ctk.CTkEntry(
            tab, placeholder_text="e.g. gpt-4o-mini",
            height=42, fg_color=cfg.SURFACE, border_color=cfg.BORDER,
            border_width=1, text_color=cfg.TEXT, corner_radius=10, font=cfg.BODY_FONT,
        )
        self._model_entry.pack(fill="x", padx=8)
        self._model_entry.insert(0, get_model(self._pvar.get()))

        ctk.CTkButton(
            tab, text="Save & Apply", height=42,
            fg_color=cfg.PRIMARY, hover_color=cfg.ACCENT,
            text_color="#000000", corner_radius=10,
            font=(cfg.FONT, 13, "bold"),
            command=self._save_provider,
        ).pack(fill="x", padx=8, pady=20)

    def _on_p_change(self, v):
        self._model_entry.delete(0, "end")
        self._model_entry.insert(0, get_model(v))

    def _save_provider(self):
        p = self._pvar.get()
        m = self._model_entry.get().strip()
        save_active_provider(p)
        if m:
            save_model(p, m)
        reload_provider()
        self._toast("Provider saved ✓")

    def _build_about(self):
        tab = self.tabs.tab("About")
        ctk.CTkLabel(tab, text="🌀", font=(cfg.FONT, 48)).pack(pady=(24, 4))
        ctk.CTkLabel(
            tab, text=cfg.APP_NAME,
            font=cfg.HEADING_FONT, text_color=cfg.TEXT,
        ).pack()
        ctk.CTkLabel(
            tab, text=f"Version {cfg.APP_VERSION}",
            font=cfg.SMALL_FONT, text_color=cfg.TEXT_SECONDARY,
        ).pack(pady=(2, 12))
        ctk.CTkLabel(
            tab,
            text="Multi-provider AI assistant.\nSupports OpenAI · Gemini · Anthropic · Ollama\n\nBuilt with Python + CustomTkinter",
            font=cfg.BODY_FONT, text_color=cfg.TEXT_SECONDARY, justify="center",
        ).pack()

    def _toast(self, msg):
        t = ctk.CTkLabel(
            self, text=msg,
            fg_color=cfg.PRIMARY, text_color="#000000",
            corner_radius=8, font=(cfg.FONT, 12, "bold"),
            padx=14, pady=5,
        )
        t.place(relx=0.5, rely=0.97, anchor="s")
        self.after(2000, t.destroy)
