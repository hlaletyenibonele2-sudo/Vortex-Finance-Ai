"""
=========================================
VORTEX - WELCOME SCREEN
=========================================
Matches reference: big spiral logo center,
VORTEX title, subtitle, greeting card.
"""

import math
import tkinter as tk
import customtkinter as ctk
import core.config as cfg


# ── Tiffany Blue spiral logo drawn with tkinter Canvas ──────────────────────

class SpiralLogo(tk.Canvas):
    """Animated Tiffany Blue / white vortex spiral."""

    SIZE = 220

    def __init__(self, parent, **kwargs):
        super().__init__(
            parent,
            width=self.SIZE,
            height=self.SIZE,
            bg=cfg.BACKGROUND,
            highlightthickness=0,
            **kwargs,
        )
        self._angle = 0
        self._draw()
        self._animate()

    def _draw(self):
        self.delete("all")
        cx = cy = self.SIZE / 2
        r = self.SIZE / 2 - 6
        offset = self._angle

        # Tiffany gradient arms: 3 arms, each fades from white → tiffany → dark
        arms = 3
        for arm in range(arms):
            base_angle = arm * (360 / arms) + offset
            pts = []
            for i in range(180):
                t = i / 179
                angle_rad = math.radians(base_angle + t * 420)
                radius = r * (0.18 + 0.82 * t)
                x = cx + radius * math.cos(angle_rad)
                y = cy + radius * math.sin(angle_rad)
                pts.append((x, y))

            # Draw with colour segments
            segments = 30
                
            for s in range(segments):
                start = int(s * 180 / segments)
                end   = int((s + 1) * 180 / segments)
                if end >= len(pts):
                    end = len(pts) - 1
                t = s / segments
                # Blend white → tiffany → dark-tiffany
                if t < 0.5:
                    r2, g2, b2 = self._lerp(
                        (255, 255, 255),
                        (10, 191, 188),
                        t * 2,
                    )
                else:
                    r2, g2, b2 = self._lerp(
                        (10, 191, 188),
                        (4, 60, 60),
                        (t - 0.5) * 2,
                    )
                width = max(1, int(10 * (1 - t * 0.6)))
                color = f"#{r2:02x}{g2:02x}{b2:02x}"
                p1, p2 = pts[start], pts[end]
                self.create_line(
                    p1[0], p1[1], p2[0], p2[1],
                    fill=color,
                    width=width,
                    capstyle="round",
                    smooth=True,
                )

        # Bright center glow
        glow_r = 18
        self.create_oval(
            cx - glow_r, cy - glow_r,
            cx + glow_r, cy + glow_r,
            fill=cfg.TIFFANY_GLOW,
            outline="",
        )
        self.create_oval(
            cx - 8, cy - 8,
            cx + 8, cy + 8,
            fill="#FFFFFF",
            outline="",
        )

    def _animate(self):
        self._angle = (self._angle + 0.6) % 360
        self._draw()
        self.after(30, self._animate)

    @staticmethod
    def _lerp(c1, c2, t):
        return (
            int(c1[0] + (c2[0] - c1[0]) * t),
            int(c1[1] + (c2[1] - c1[1]) * t),
            int(c1[2] + (c2[2] - c1[2]) * t),
        )


# ── Welcome Screen ───────────────────────────────────────────────────────────

class WelcomeScreen(ctk.CTkFrame):

    def __init__(self, parent, on_suggestion, **kwargs):
        super().__init__(parent, fg_color=cfg.BACKGROUND, **kwargs)
        self.on_suggestion = on_suggestion

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self._build()

    def _build(self):

        center = ctk.CTkFrame(self, fg_color="transparent")
        center.place(relx=0.5, rely=0.44, anchor="center")

        # Animated spiral logo
        SpiralLogo(center).pack(pady=(0, 6))

        # VORTEX title — gradient-style using two labels side by side
        title_row = ctk.CTkFrame(center, fg_color="transparent")
        title_row.pack()

        ctk.CTkLabel(
            title_row,
            text="VORTEX",
            font=(cfg.FONT, 46, "bold"),
            text_color=cfg.PRIMARY,
        ).pack()

        # Subtitle
        ctk.CTkLabel(
            center,
            text="Your AI Assistant",
            font=(cfg.FONT, 15),
            text_color=cfg.TEXT_SECONDARY,
        ).pack(pady=(2, 24))

        # Greeting card
        card = ctk.CTkFrame(
            center,
            fg_color=cfg.SURFACE,
            corner_radius=16,
        )
        card.pack(fill="x", pady=(0, 0), ipadx=20, ipady=16)

        greeting = ctk.CTkFrame(card, fg_color="transparent")
        greeting.pack(padx=24, pady=16)

        line1 = ctk.CTkFrame(greeting, fg_color="transparent")
        line1.pack(anchor="w")

        ctk.CTkLabel(
            line1,
            text="Hello! I'm ",
            font=(cfg.FONT, 16),
            text_color=cfg.TEXT,
        ).pack(side="left")

        ctk.CTkLabel(
            line1,
            text="Vortex",
            font=(cfg.FONT, 16, "bold"),
            text_color=cfg.PRIMARY,
        ).pack(side="left")

        ctk.CTkLabel(
            line1,
            text=".",
            font=(cfg.FONT, 16),
            text_color=cfg.TEXT,
        ).pack(side="left")

        ctk.CTkLabel(
            greeting,
            text="How can I help you today?",
            font=(cfg.FONT, 15),
            text_color=cfg.TEXT_SECONDARY,
            anchor="w",
        ).pack(anchor="w", pady=(4, 0))
