"""
=========================================
VORTEX - SIDEBAR
=========================================
Matches the reference screenshot layout:
  logo + name top, new-chat, search, recent-chats label,
  chat list, Vortex Pro banner, Guest + settings bottom.
"""

import customtkinter as ctk
import core.config as cfg


class Sidebar(ctk.CTkFrame):

    def __init__(self, parent, on_new_chat, on_open_chat,
                 on_delete_chat, on_settings, **kwargs):

        super().__init__(
            parent,
            width=cfg.SIDEBAR_WIDTH,
            fg_color=cfg.SIDEBAR,
            corner_radius=0,
            **kwargs
        )

        self.on_new_chat    = on_new_chat
        self.on_open_chat   = on_open_chat
        self.on_delete_chat = on_delete_chat
        self.on_settings    = on_settings

        self.pack_propagate(False)
        self._build()

    # ============================
    # BUILD
    # ============================

    def _build(self):

        # ── TOP: Logo + Name ──────────────────────────
        logo_row = ctk.CTkFrame(self, fg_color="transparent")
        logo_row.pack(fill="x", padx=18, pady=(22, 16))

        # Circular tiffany logo badge
        logo_badge = ctk.CTkFrame(
            logo_row,
            width=38, height=38,
            fg_color=cfg.PRIMARY,
            corner_radius=19,
        )
        logo_badge.pack(side="left")
        logo_badge.pack_propagate(False)
        ctk.CTkLabel(
            logo_badge,
            text="🌀",
            font=("Segoe UI", 18),
            text_color="#000000",
        ).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            logo_row,
            text="  VORTEX",
            font=(cfg.FONT, 17, "bold"),
            text_color=cfg.TEXT,
        ).pack(side="left")

        # ── New Chat button ───────────────────────────
        ctk.CTkButton(
            self,
            text="＋  New Chat",
            height=cfg.BUTTON_HEIGHT,
            fg_color=cfg.PRIMARY,
            hover_color=cfg.ACCENT,
            text_color="#000000",
            corner_radius=cfg.CORNER_RADIUS,
            font=(cfg.FONT, 14, "bold"),
            command=self.on_new_chat,
        ).pack(fill="x", padx=16, pady=(0, 10))

        # ── Search ────────────────────────────────────
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", self._on_search)

        search_frame = ctk.CTkFrame(self, fg_color=cfg.SURFACE, corner_radius=10)
        search_frame.pack(fill="x", padx=16, pady=(0, 12))
        search_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            search_frame,
            text="🔍",
            font=(cfg.FONT, 13),
            text_color=cfg.TEXT_SECONDARY,
        ).grid(row=0, column=0, padx=(10, 4), pady=8)

        self._search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="Search chats...",
            height=36,
            fg_color="transparent",
            border_width=0,
            text_color=cfg.TEXT,
            placeholder_text_color=cfg.TEXT_SECONDARY,
            font=cfg.BODY_FONT,
            textvariable=self.search_var,
        )
        self._search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 8))

        # ── Recent Chats label ────────────────────────
        ctk.CTkLabel(
            self,
            text="Recent Chats",
            font=(cfg.FONT, 11, "bold"),
            text_color=cfg.TEXT_SECONDARY,
            anchor="w",
        ).pack(fill="x", padx=20, pady=(0, 6))

        # ── Chat list ─────────────────────────────────
        self.list_frame = ctk.CTkScrollableFrame(
            self,
            fg_color="transparent",
            scrollbar_button_color=cfg.SURFACE,
            scrollbar_button_hover_color=cfg.BORDER,
        )
        self.list_frame.pack(fill="both", expand=True, padx=8)
        self._chat_buttons = {}

        # ── Vortex Pro Banner ─────────────────────────
        pro_frame = ctk.CTkFrame(
            self,
            fg_color=cfg.CARD,
            corner_radius=12,
            border_width=1,
            border_color=cfg.PRIMARY,
        )
        pro_frame.pack(fill="x", padx=14, pady=(8, 0))
        pro_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            pro_frame,
            text="👑",
            font=(cfg.FONT, 20),
        ).grid(row=0, column=0, rowspan=2, padx=(12, 8), pady=12)

        ctk.CTkLabel(
            pro_frame,
            text="Vortex Pro",
            font=(cfg.FONT, 13, "bold"),
            text_color=cfg.TEXT,
            anchor="w",
        ).grid(row=0, column=1, sticky="w", pady=(10, 0))

        ctk.CTkLabel(
            pro_frame,
            text="Unlock unlimited access",
            font=(cfg.FONT, 11),
            text_color=cfg.TEXT_SECONDARY,
            anchor="w",
        ).grid(row=1, column=1, sticky="w", pady=(0, 10))

        ctk.CTkLabel(
            pro_frame,
            text="›",
            font=(cfg.FONT, 18),
            text_color=cfg.TEXT_SECONDARY,
        ).grid(row=0, column=2, rowspan=2, padx=(0, 12))

        # ── Bottom: Guest + Settings ──────────────────
        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.pack(fill="x", padx=14, pady=(10, 14))
        bottom.grid_columnconfigure(1, weight=1)

        # Avatar circle
        avatar = ctk.CTkFrame(
            bottom,
            width=36, height=36,
            fg_color=cfg.CARD,
            corner_radius=18,
        )
        avatar.grid(row=0, column=0)
        avatar.grid_propagate(False)
        ctk.CTkLabel(
            avatar,
            text="👤",
            font=(cfg.FONT, 16),
        ).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            bottom,
            text="  Guest",
            font=(cfg.FONT, 13, "bold"),
            text_color=cfg.TEXT,
            anchor="w",
        ).grid(row=0, column=1, sticky="w")

        ctk.CTkButton(
            bottom,
            text="⚙",
            width=32,
            height=32,
            fg_color="transparent",
            hover_color=cfg.SURFACE,
            text_color=cfg.TEXT_SECONDARY,
            corner_radius=8,
            font=(cfg.FONT, 16),
            command=self.on_settings,
        ).grid(row=0, column=2)

    # ============================
    # POPULATE
    # ============================

    def populate(self, chats):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self._chat_buttons = {}
        for chat in chats:
            self._add_chat_row(chat)

    def _add_chat_row(self, chat):

        row = ctk.CTkFrame(self.list_frame, fg_color="transparent", corner_radius=8)
        row.pack(fill="x", pady=1)
        row.grid_columnconfigure(0, weight=1)

        # Chat icon + title
        inner = ctk.CTkFrame(row, fg_color="transparent")
        inner.grid(row=0, column=0, sticky="ew")
        inner.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            inner,
            text="□",
            font=(cfg.FONT, 12),
            text_color=cfg.TEXT_SECONDARY,
            width=20,
        ).grid(row=0, column=0, padx=(6, 4))

        btn = ctk.CTkButton(
            inner,
            text=chat["title"],
            anchor="w",
            fg_color="transparent",
            hover_color=cfg.SURFACE,
            text_color=cfg.TEXT,
            font=(cfg.FONT, 13),
            corner_radius=8,
            height=38,
            command=lambda cid=chat["id"]: self.on_open_chat(cid),
        )
        btn.grid(row=0, column=1, sticky="ew")

        del_btn = ctk.CTkButton(
            row,
            text="✕",
            width=24,
            height=24,
            fg_color="transparent",
            hover_color=cfg.ERROR,
            text_color=cfg.TEXT_SECONDARY,
            corner_radius=6,
            font=(cfg.FONT, 10),
            command=lambda cid=chat["id"]: self.on_delete_chat(cid),
        )
        del_btn.grid(row=0, column=1, padx=(0, 2))

        self._chat_buttons[chat["id"]] = (btn, row)

    def highlight(self, chat_id):
        for cid, (btn, row) in self._chat_buttons.items():
            is_active = cid == chat_id
            btn.configure(
                fg_color=cfg.SURFACE if is_active else "transparent",
                text_color=cfg.TEXT,
            )

    # ============================
    # SEARCH
    # ============================

    def _on_search(self, *_):
        self._search_query = self.search_var.get().strip()
        self.event_generate("<<SidebarSearch>>", when="tail")

    def get_search_query(self):
        return getattr(self, "_search_query", "")
