"""
=========================================
VORTEX - CHAT AREA
=========================================
Scrollable messages + input bar at bottom.
Matches reference: wide input, circular send button.
"""

import customtkinter as ctk
import core.config as cfg
from ui.message import MessageBubble


class ChatArea(ctk.CTkFrame):

    def __init__(self, parent, on_send_callback, **kwargs):
        super().__init__(parent, fg_color=cfg.BACKGROUND, **kwargs)
        self.on_send = on_send_callback
        self._typing_bubble = None

        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=1)

        self._build_messages()
        self._build_input_bar()

    # ============================
    # MESSAGES
    # ============================

    def _build_messages(self):

        self.scroll = ctk.CTkScrollableFrame(
            self,
            fg_color=cfg.BACKGROUND,
            scrollbar_button_color=cfg.SURFACE,
            scrollbar_button_hover_color=cfg.BORDER,
        )
        self.scroll.grid(row=0, column=0, sticky="nsew")
        self.scroll.grid_columnconfigure(0, weight=1)

    # ============================
    # INPUT BAR  (matches reference)
    # ============================

    def _build_input_bar(self):

        # Outer container with top border
        outer = ctk.CTkFrame(
            self,
            fg_color=cfg.SIDEBAR,
            corner_radius=0,
        )
        outer.grid(row=1, column=0, sticky="ew")
        outer.grid_columnconfigure(0, weight=1)

        # Input pill
        pill = ctk.CTkFrame(
            outer,
            fg_color=cfg.SURFACE,
            corner_radius=28,
            border_width=1,
            border_color=cfg.BORDER,
        )
        pill.pack(fill="x", padx=24, pady=16)
        pill.grid_columnconfigure(0, weight=1)

        self.entry = ctk.CTkEntry(
            pill,
            placeholder_text="Type your message...",
            height=cfg.INPUT_HEIGHT,
            fg_color="transparent",
            border_width=0,
            text_color=cfg.TEXT,
            placeholder_text_color=cfg.TEXT_SECONDARY,
            font=(cfg.FONT, 14),
        )
        self.entry.grid(row=0, column=0, sticky="ew", padx=(20, 8), pady=4)
        self.entry.bind("<Return>", lambda e: self._send())

        # Circular send button
        self.send_btn = ctk.CTkButton(
            pill,
            text="➤",
            width=cfg.SEND_BUTTON_SIZE,
            height=cfg.SEND_BUTTON_SIZE,
            fg_color=cfg.PRIMARY,
            hover_color=cfg.ACCENT,
            text_color="#000000",
            corner_radius=cfg.SEND_BUTTON_SIZE // 2,
            font=(cfg.FONT, 16, "bold"),
            command=self._send,
        )
        self.send_btn.grid(row=0, column=1, padx=(0, 8), pady=4)

    # ============================
    # ACTIONS
    # ============================

    def _send(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self.on_send(text)

    def add_message(self, role, content, timestamp=""):
        bubble = MessageBubble(
            self.scroll,
            role=role,
            content=content,
            timestamp=timestamp,
        )
        bubble.grid(
            row=len(self.scroll.winfo_children()),
            column=0,
            sticky="ew",
            pady=3,
        )
        self.scroll.after(60, lambda: self.scroll._parent_canvas.yview_moveto(1.0))

    def show_typing(self):
        """Show animated typing indicator."""
        if self._typing_bubble:
            return
        self._typing_bubble = ctk.CTkLabel(
            self.scroll,
            text="  Vortex is thinking…",
            font=(cfg.FONT, 13),
            text_color=cfg.TEXT_SECONDARY,
            fg_color=cfg.SURFACE,
            corner_radius=12,
            anchor="w",
        )
        self._typing_bubble.grid(
            row=len(self.scroll.winfo_children()),
            column=0,
            sticky="w",
            padx=24,
            pady=6,
        )
        self.scroll.after(60, lambda: self.scroll._parent_canvas.yview_moveto(1.0))

    def hide_typing(self):
        if self._typing_bubble:
            self._typing_bubble.destroy()
            self._typing_bubble = None

    def clear_messages(self):
        self.hide_typing()
        for w in self.scroll.winfo_children():
            w.destroy()

    def load_history(self, messages):
        self.clear_messages()
        for row in messages:
            self.add_message(row["role"], row["content"], row["timestamp"])

    def focus_input(self):
        self.entry.focus()
