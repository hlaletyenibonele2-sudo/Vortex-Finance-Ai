# 🌀 Vortex AI

A sleek multi-provider AI assistant built with Python + CustomTkinter.

## Features
- Dark mode UI with Tiffany Blue accent
- Multi-provider: OpenAI, Google Gemini, Anthropic Claude, Ollama (local)
- Persistent chat history (SQLite)
- Animated spiral logo
- Model selector in top bar
- Settings window for API keys + provider switching

## Setup

```bash
pip install -r requirements.txt
python main.py
```

## Configuration
Open ⚙ Settings → API Keys to add your keys.
Switch providers under Settings → Provider.

## Providers
| Provider  | Requires          |
|-----------|-------------------|
| OpenAI    | OPENAI_API_KEY    |
| Gemini    | GEMINI_API_KEY    |
| Anthropic | ANTHROPIC_API_KEY |
| Ollama    | Running locally   |
