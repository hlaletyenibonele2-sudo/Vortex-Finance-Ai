"""
=========================================
VORTEX AI — ENTRY POINT
=========================================
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from core.database import initialize_database
from ui.app import VortexApp


def main():
    initialize_database()
    app = VortexApp()
    app.mainloop()


if __name__ == "__main__":
    main()
