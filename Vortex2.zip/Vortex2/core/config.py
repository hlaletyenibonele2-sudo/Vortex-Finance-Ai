"""
=========================================
VORTEX CONFIGURATION  — Tiffany Blue Dark
=========================================
"""

from pathlib import Path

# =====================================================
# APPLICATION
# =====================================================

APP_NAME    = "Vortex AI"
APP_VERSION = "2.0.0"

WINDOW_WIDTH  = 1400
WINDOW_HEIGHT = 860
MIN_WIDTH     = 1100
MIN_HEIGHT    = 680

# =====================================================
# PROJECT PATHS
# =====================================================

ROOT_DIR      = Path(__file__).resolve().parent.parent
DATA_DIR      = ROOT_DIR / "data"
ASSETS_DIR    = ROOT_DIR / "assets"
ICONS_DIR     = ASSETS_DIR / "icons"
LOGO_DIR      = ASSETS_DIR / "logo"
FONTS_DIR     = ASSETS_DIR / "fonts"
DATABASE_PATH = DATA_DIR / "vortex.db"

# =====================================================
# DARK THEME  (primary — Tiffany Blue)
# =====================================================

TIFFANY      = "#0ABFBC"
TIFFANY_LITE = "#81D8D0"
TIFFANY_GLOW = "#1DE9E5"

BACKGROUND      = "#0A0A0F"   # near-black background
SIDEBAR         = "#0E0E16"   # sidebar slightly lighter
SURFACE         = "#14141F"   # cards / bubbles
CARD            = "#1A1A28"   # input bar, elevated cards
PRIMARY         = TIFFANY
ACCENT          = TIFFANY_GLOW
SUCCESS         = "#00E5A0"
WARNING         = "#F59E0B"
ERROR           = "#FF4D6D"
TEXT            = "#F0FAFA"
TEXT_SECONDARY  = "#6BBDBA"
BORDER          = "#1E2235"
USER_BUBBLE     = TIFFANY
AI_BUBBLE       = SURFACE
USER_TEXT       = "#000000"
AI_TEXT         = TEXT

# =====================================================
# LIGHT THEME  (for settings toggle — optional)
# =====================================================

LIGHT_BACKGROUND     = "#F4FCFC"
LIGHT_SIDEBAR        = "#E8F7F7"
LIGHT_SURFACE        = "#FFFFFF"
LIGHT_PRIMARY        = TIFFANY
LIGHT_TEXT           = "#0A1F1F"
LIGHT_TEXT_SECONDARY = "#3D7E7C"
LIGHT_BORDER         = "#B2DEDC"

# =====================================================
# THEME CONSTANTS
# =====================================================

DARK_MODE     = "dark"
LIGHT_MODE    = "light"
DEFAULT_THEME = DARK_MODE

# =====================================================
# SIDEBAR
# =====================================================

SIDEBAR_WIDTH  = 300
SEARCH_HEIGHT  = 40
BUTTON_HEIGHT  = 44
CORNER_RADIUS  = 12

# =====================================================
# CHAT
# =====================================================

MAX_BUBBLE_WIDTH = 720
WRAP_LENGTH      = 680
INPUT_HEIGHT     = 52
SEND_BUTTON_SIZE = 46

# =====================================================
# FONTS
# =====================================================

FONT         = "Segoe UI"
TITLE_FONT   = (FONT, 40, "bold")
HEADING_FONT = (FONT, 20, "bold")
BODY_FONT    = (FONT, 14)
SMALL_FONT   = (FONT, 12)
CODE_FONT    = ("Consolas", 13)

# =====================================================
# AI / DB
# =====================================================

DEFAULT_PROVIDER   = "openai"
REQUEST_TIMEOUT    = 60
STREAM_RESPONSES   = True
AUTO_TITLE_LENGTH  = 40
DATABASE_NAME      = "vortex.db"

# =====================================================
# LOGGING
# =====================================================

LOG_FILE = DATA_DIR / "vortex.log"

# =====================================================
# CREATE DIRECTORIES
# =====================================================

DATA_DIR.mkdir(exist_ok=True)
ASSETS_DIR.mkdir(exist_ok=True)
ICONS_DIR.mkdir(exist_ok=True)
LOGO_DIR.mkdir(exist_ok=True)
FONTS_DIR.mkdir(exist_ok=True)
