from core.database import get_setting, set_setting
import core.config as cfg

def get_api_key(provider):
    return get_setting(f"api_key_{provider}") or ""

def save_api_key(provider, key):
    set_setting(f"api_key_{provider}", key)

def get_active_provider():
    return get_setting("provider") or cfg.DEFAULT_PROVIDER

def save_active_provider(provider):
    set_setting("provider", provider)

def get_model(provider):
    defaults = {
        "openai": "gpt-4o-mini",
        "gemini": "gemini-1.5-flash",
        "ollama": "llama3",
        "anthropic": "claude-3-haiku-20240307",
    }
    return get_setting(f"model_{provider}") or defaults.get(provider, "")

def save_model(provider, model):
    set_setting(f"model_{provider}", model)
