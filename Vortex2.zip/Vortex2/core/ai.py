"""
=========================================
VORTEX AI ENGINE
=========================================

Every AI provider is accessed through this file.
The UI never talks directly to any provider SDK.

Supported Providers:
- OpenAI
- Gemini (Google)
- Anthropic (Claude)
- Ollama (local)
"""

import os
from abc import ABC, abstractmethod
from core.settings import get_api_key, get_model


# ==========================================
# BASE PROVIDER
# ==========================================

class AIProvider(ABC):

    @abstractmethod
    def generate(self, messages: list[dict]) -> str:
        """
        messages: list of {"role": "user"|"assistant", "content": str}
        Returns the assistant reply string.
        """
        pass


# ==========================================
# OFFLINE PROVIDER
# ==========================================

class OfflineProvider(AIProvider):

    def generate(self, messages):
        return (
            "⚠️ VORTEX IS OFFLINE\n\n"
            "No AI provider is currently configured.\n\n"
            "Open ⚙ Settings to add an API key for\n"
            "OpenAI, Gemini, Anthropic, or Ollama."
        )


# ==========================================
# OPENAI PROVIDER
# ==========================================

class OpenAIProvider(AIProvider):

    def __init__(self):
        self.client = None
        key = get_api_key("openai")
        if key:
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=key)
            except Exception:
                pass

    def generate(self, messages):
        if not self.client:
            return OfflineProvider().generate(messages)
        try:
            model = get_model("openai")
            resp = self.client.chat.completions.create(
                model=model or "gpt-4o-mini",
                messages=messages,
            )
            return resp.choices[0].message.content
        except Exception as e:
            return f"❌ OpenAI error: {e}"


# ==========================================
# GEMINI PROVIDER
# ==========================================

class GeminiProvider(AIProvider):

    def __init__(self):
        self.model = None
        key = get_api_key("gemini")
        if key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=key)
                model_name = get_model("gemini") or "gemini-1.5-flash"
                self.model = genai.GenerativeModel(model_name)
            except Exception:
                pass

    def generate(self, messages):
        if not self.model:
            return OfflineProvider().generate(messages)
        try:
            # Build Gemini-compatible history
            history = []
            for m in messages[:-1]:
                history.append({
                    "role": "user" if m["role"] == "user" else "model",
                    "parts": [m["content"]]
                })
            last = messages[-1]["content"]
            chat = self.model.start_chat(history=history)
            resp = chat.send_message(last)
            return resp.text
        except Exception as e:
            return f"❌ Gemini error: {e}"


# ==========================================
# ANTHROPIC PROVIDER
# ==========================================

class AnthropicProvider(AIProvider):

    def __init__(self):
        self.client = None
        key = get_api_key("anthropic")
        if key:
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=key)
            except Exception:
                pass

    def generate(self, messages):
        if not self.client:
            return OfflineProvider().generate(messages)
        try:
            model = get_model("anthropic") or "claude-3-haiku-20240307"
            resp = self.client.messages.create(
                model=model,
                max_tokens=4096,
                messages=messages,
            )
            return resp.content[0].text
        except Exception as e:
            return f"❌ Anthropic error: {e}"


# ==========================================
# OLLAMA PROVIDER  (local)
# ==========================================

class OllamaProvider(AIProvider):

    def generate(self, messages):
        try:
            import requests
            model = get_model("ollama") or "llama3"
            payload = {"model": model, "messages": messages, "stream": False}
            resp = requests.post(
                "http://localhost:11434/api/chat",
                json=payload,
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]
        except Exception as e:
            return f"❌ Ollama error: {e}\n\nMake sure Ollama is running locally."


# ==========================================
# PROVIDER REGISTRY
# ==========================================

_PROVIDERS = {
    "openai":    OpenAIProvider,
    "gemini":    GeminiProvider,
    "anthropic": AnthropicProvider,
    "ollama":    OllamaProvider,
}


# ==========================================
# AI ENGINE
# ==========================================

class AIEngine:

    def __init__(self):
        self._provider: AIProvider = OfflineProvider()
        self._history: list[dict] = []

    def load_provider(self, name: str):
        """Instantiate provider by name (from settings)."""
        cls = _PROVIDERS.get(name)
        if cls:
            self._provider = cls()
        else:
            self._provider = OfflineProvider()

    def set_provider(self, provider: AIProvider):
        self._provider = provider

    def ask(self, prompt: str) -> str:
        self._history.append({"role": "user", "content": prompt})
        reply = self._provider.generate(list(self._history))
        self._history.append({"role": "assistant", "content": reply})
        return reply

    def clear_history(self):
        self._history = []


# ==========================================
# GLOBAL ENGINE
# ==========================================

_engine = AIEngine()


def initialise_engine():
    from core.settings import get_active_provider
    _engine.load_provider(get_active_provider())


def ask_ai(prompt: str) -> str:
    return _engine.ask(prompt)


def clear_ai_history():
    _engine.clear_history()


def reload_provider():
    from core.settings import get_active_provider
    _engine.load_provider(get_active_provider())
    clear_ai_history()
