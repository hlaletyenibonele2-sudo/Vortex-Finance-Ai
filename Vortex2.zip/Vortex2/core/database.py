import sqlite3
import os

DB_NAME = os.path.join(
    os.path.dirname(__file__),
    "..",
    "data",
    "vortex.db"
)


# =====================================================
# CONNECT
# =====================================================

def connect():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


# =====================================================
# INITIALIZE DATABASE
# =====================================================

def initialize_database():

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chats (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        title TEXT NOT NULL,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        chat_id INTEGER NOT NULL,

        role TEXT NOT NULL,

        content TEXT NOT NULL,

        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(chat_id) REFERENCES chats(id)
            ON DELETE CASCADE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (

        key TEXT PRIMARY KEY,

        value TEXT
    )
    """)

    conn.commit()
    conn.close()


# =====================================================
# CHAT FUNCTIONS
# =====================================================

def create_chat(title="New Chat"):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO chats(title)
        VALUES(?)
        """,
        (title,)
    )

    chat_id = cursor.lastrowid

    conn.commit()
    conn.close()

    return chat_id


def rename_chat(chat_id, title):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE chats
        SET title=?
        WHERE id=?
        """,
        (title, chat_id)
    )

    conn.commit()
    conn.close()


def delete_chat(chat_id):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM chats WHERE id=?",
        (chat_id,)
    )

    conn.commit()
    conn.close()


def update_chat_timestamp(chat_id):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE chats
        SET updated_at=CURRENT_TIMESTAMP
        WHERE id=?
        """,
        (chat_id,)
    )

    conn.commit()
    conn.close()


# =====================================================
# MESSAGE FUNCTIONS
# =====================================================

def add_message(chat_id, role, content):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO messages
        (chat_id, role, content)

        VALUES (?, ?, ?)
        """,
        (chat_id, role, content)
    )

    cursor.execute(
        """
        UPDATE chats
        SET updated_at=CURRENT_TIMESTAMP
        WHERE id=?
        """,
        (chat_id,)
    )

    conn.commit()
    conn.close()


def get_messages(chat_id):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT role, content, timestamp

        FROM messages

        WHERE chat_id=?

        ORDER BY id ASC
        """,
        (chat_id,)
    )

    rows = cursor.fetchall()

    conn.close()

    return rows


# =====================================================
# CHAT LIST
# =====================================================

def get_all_chats():

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT *

    FROM chats

    ORDER BY updated_at DESC
    """)

    chats = cursor.fetchall()

    conn.close()

    return chats


def search_chats(query):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *

        FROM chats

        WHERE title LIKE ?

        ORDER BY updated_at DESC
        """,
        (f"%{query}%",)
    )

    results = cursor.fetchall()

    conn.close()

    return results


# =====================================================
# SETTINGS
# =====================================================

def set_setting(key, value):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO settings(key,value)

        VALUES(?,?)

        ON CONFLICT(key)

        DO UPDATE SET value=excluded.value
        """,
        (key, value)
    )

    conn.commit()
    conn.close()


def get_setting(key):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT value

        FROM settings

        WHERE key=?
        """,
        (key,)
    )

    row = cursor.fetchone()

    conn.close()

    if row:
        return row["value"]

    return None
    
