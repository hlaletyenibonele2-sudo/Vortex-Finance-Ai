"""
=========================================
VORTEX THEME MANAGER  (lightweight)
=========================================
"""

import customtkinter as ctk
from core.database import set_setting, get_setting
import core.config as cfg


class ThemeManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._mode = get_setting("theme") or cfg.DEFAULT_THEME
        return cls._instance

    @property
    def is_dark(self):
        return self._mode == cfg.DARK_MODE

    def toggle(self):
        new = cfg.LIGHT_MODE if self.is_dark else cfg.DARK_MODE
        self._mode = new
        set_setting("theme", new)
        ctk.set_appearance_mode("dark" if new == cfg.DARK_MODE else "light")

def get_theme_manager():
    return ThemeManager()
