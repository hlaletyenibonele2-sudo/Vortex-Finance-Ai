from core.database import (
    create_chat,
    add_message,
    get_messages,
    get_all_chats,
    search_chats,
    rename_chat,
    delete_chat
)

from core.ai import ask_ai


class ChatManager:

    def __init__(self):

        self.current_chat_id = None
        self.current_title = None

    # ============================
    # CREATE CHAT
    # ============================

    def new_chat(self):

        self.current_chat_id = None
        self.current_title = None

    # ============================
    # SEND MESSAGE
    # ============================

    def send_message(self, question):

        question = question.strip()

        if not question:
            return None

        if self.current_chat_id is None:

            title = self.generate_title(question)

            self.current_chat_id = create_chat(title)

            self.current_title = title

        add_message(
            self.current_chat_id,
            "user",
            question
        )

        try:

            answer = ask_ai(question)

        except Exception:

            answer = (
                "⚠️ VORTEX IS OFFLINE\n\n"
                "No AI provider is currently available."
            )

        add_message(
            self.current_chat_id,
            "assistant",
            answer
        )

        return answer

    # ============================
    # LOAD CHAT
    # ============================

    def open_chat(self, chat_id):

        self.current_chat_id = chat_id

        return get_messages(chat_id)

    # ============================
    # SIDEBAR
    # ============================

    def get_chats(self):

        return get_all_chats()

    def search(self, text):

        return search_chats(text)

    # ============================
    # DELETE
    # ============================

    def delete(self, chat_id):

        delete_chat(chat_id)

    # ============================
    # RENAME
    # ============================

    def rename(self, chat_id, title):

        rename_chat(chat_id, title)

    # ============================
    # TITLE
    # ============================

    @staticmethod
    def generate_title(question):

        question = question.strip()

        if len(question) <= 40:
            return question

        return question[:40] + "..."
